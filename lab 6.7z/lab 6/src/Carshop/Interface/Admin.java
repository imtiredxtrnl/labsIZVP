package Carshop.Interface;

public interface Admin {
    int getIncome();
}
